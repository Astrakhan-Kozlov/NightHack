from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, \
    InlineKeyboardMarkup, InlineKeyboardButton
from config import ASSOCIATIONS_OF_PR

keyboard_settings = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Настройки")]],
    resize_keyboard=True
)

keyboard_back = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад")]],
    resize_keyboard=True
)

settings = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text='Выбрать сайт', callback_data='choose_site')],
    [InlineKeyboardButton(text='История', callback_data='history')]
    ])

site = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text='habr',callback_data='habr_button')],
    [InlineKeyboardButton(text='cyberforum',callback_data='cyberforum_button')],
    [InlineKeyboardButton(text='stackoverflow',callback_data='stackoverflow_button')],
    [InlineKeyboardButton(text='назад',callback_data='back_button')]
    ])


def get_sites_buttons(value):
    buttons = []

    for abbr, title in ASSOCIATIONS_OF_PR.items():
        buttons.append([InlineKeyboardButton(
            text = title + ' ' + ('✅' if value[abbr] else '❌'), callback_data=abbr
    )])
        
        
    back_button = [InlineKeyboardButton(text="Назад", callback_data="back")]
    return InlineKeyboardMarkup(inline_keyboard=buttons + [back_button])
