TOKEN = ''

ASSOCIATIONS_OF_PR = {
    'hr': 'Habr',
    'cf': 'Cyberforum',
    'sof': 'StackOverFlow'
}
