from parsers.baseParser import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import time
from random import randint

class CyberForumParser(BaseParser):
    def __init__(self):
        pass
    
    def getURL(self):
        url = 'https://www.cyberforum.ru/search.php?do=process'
        return url

    def brow(self, question):
        results = []
        for i in range(1):
            try:
                url = self.getURL()
                browser = BaseParser.create_driver()
                browser.get(url)
                print('Браузер открыт')
                
                search = WebDriverWait(browser, 10).until(
                    EC.presence_of_element_located((By.NAME, "query"))
                )
                
                search.send_keys(''.join(question))

                recaptcha_iframe = WebDriverWait(browser, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//iframe[@title="reCAPTCHA"]'))
                )
                browser.switch_to.frame(recaptcha_iframe)

                checkbox = WebDriverWait(browser, 10).until(
                    EC.element_to_be_clickable((By.XPATH, '//div[@class="recaptcha-checkbox-border"]'))
                )
                checkbox.click()
                time.sleep(4 + randint(0, 2))
                print("Начат поиск")
                browser.switch_to.default_content()
                
                search.send_keys('\n')
                time.sleep(4)
                print("Выбор подходящих тем")
                articles = browser.find_elements(By.TAG_NAME, 'a')
                        
                results = []
                for i, topic in enumerate(articles[25:29]):
                    time.sleep(1)
                    link = topic.get_attribute("href")
                    results.append(BaseParser.getValues(link, topic.text, topic.text[:30]))

                browser.close()
            except Exception as ex:
                print(ex)
        return results
