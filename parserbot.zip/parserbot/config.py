TOKEN = '7413435747:AAEDpIQEmAVCqdVfM4vOxuq7A-4m7i2qByY'
#TOKEN = '8090531743:AAGPImdKi5ZBeXa67_k1DiEYO-osUKrMSDo'

ASSOCIATIONS_OF_PR = {
    'hr': 'Habr',
    'cf': 'Cyberforum',
    'sof': 'StackOverFlow'
}
