from parsers.baseParser import *
from selenium.webdriver.common.by import By
import time


class HabrParser(BaseParser):
    def __init__(self): pass
    
    def getURL(self, q):
        url = f'https://habr.com/ru/search/?q={q}&target_type=posts&order=relevance'
        return url

    def brow(self, question):
        results = []
        try:
            url = self.getURL(question)
            browser = BaseParser.create_driver()
            browser.get(url)

            articles = browser.find_elements(By.CLASS_NAME, 'tm-articles-list__item')
            for art in articles[:5]:
                time.sleep(2)
                title = art.find_element(By.CLASS_NAME, 'tm-title__link').text
                a = art.find_element(By.CLASS_NAME, 'tm-article-snippet__readmore')
                summ = art.find_element(By.CLASS_NAME, 'article-formatted-body').text[:100]
                link = a.get_attribute('href')
                if BaseParser.detectRelevance(title, question):
                    print(1)
                    results.append(BaseParser.getValues(link, title, summ))
                else: # Если нерелевантно, то ничего не делаем
                    print(0)
            
            browser.close()
        except Exception as ex:
            print(ex)
        return results
