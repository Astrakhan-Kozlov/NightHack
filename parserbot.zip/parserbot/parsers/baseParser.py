import abc
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium_stealth import stealth
from fake_useragent import UserAgent

#PATH_TO_DRIVER = r'C:\chromedriver-win64\chromedriver-win64\chromedriver.exe'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

class IParser(abc.ABC):
    @abc.abstractmethod
    def get_random_US(): pass

    @abc.abstractmethod
    def create_driver(): pass

    @abc.abstractmethod
    def getValues(linkURL, title, id_, rating, price, review): pass

    @abc.abstractmethod
    def detectRelevance(title, product): pass

    @abc.abstractmethod
    def retryingFindClassElement(browser, name): pass

    @abc.abstractmethod
    def retryingFindIdElement(browser, name): pass

    @abc.abstractmethod
    def getURL(nums, product): pass

    @abc.abstractmethod
    def brow(product): pass


class BaseParser(IParser):
    def get_random_US():
        user_agent = UserAgent(browsers='chrome', os='windows', platforms='pc')
        return user_agent.random

    def create_driver():
        options = Options()
        options.add_argument("start-maximized")

        options.add_argument("--user-data-dir=C:\\Users\\Admin\\AppData\\Local\\Google\\Chrome\\User Data")
        options.add_argument("--profile-directory=Default")

        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)

        options.add_argument('--disable-gpu') 
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument("--disable-notifications")
        options.add_argument("--disable-popup-blocking")
        options.add_argument('--no-sandbox')
        #options.add_argument('headless')
        #options.add_argument('blink-settings=imagesEnabled=false')
        #options.add_argument('--disable-extensions')  # Отключение расширений
        #options.add_argument('--disable-plugins')  # Отключение плагинов
        #options.add_argument('--disable-logging')  # Отключение логирования
        #options.add_argument('--autoplay-policy=no-user-gesture-required')  # Отключаем авто-воспроизведение

        driver = webdriver.Chrome(options=options)
    
        stealth(driver=driver,
                user_agent=BaseParser.get_random_US(),
                languages=["ru-RU", "ru"],
                vendor="Google Inc.",
                platform="Win32",
                webgl_vendor="Intel Inc.",
                renderer="Intel Iris OpenGL Engine",
                fix_hairline=True,
                run_on_insecure_origins=True
                )

        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            'source': '''
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
          '''
        })
        return driver

    def getValues(linkURL, title, summ):
        res_dct = {
            'Ссылка': linkURL,
            'Название': title,
            'Аннотация': summ
            }
        return res_dct

    def detectRelevance(title, product):
        for word in product.split():
           if word.lower() in [elem.lower() for elem in title.split()]:
              return True
        return False

    def retryingFindClassElement(browser, name):
        attempts = 0
        cycles = 0
        obj = None
        while attempts < 12:
            try:
                #obj = browser.find_element(By.CLASS_NAME, name)
                obj = WebDriverWait(browser, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, name)))
                attempts += 1
            except Exception as ex:        
                attempts = 0
                cycles += 1
                if cycles >= 3:
                    break
        return obj

    def retryingFindIdElement(browser, name):
        attempts = 0
        cycles = 0
        obj = None
        while attempts < 12:
            try:
                #obj = browser.find_element(By.CLASS_NAME, name)
                obj = WebDriverWait(browser, 1).until(EC.element_to_be_clickable((By.ID, name)))
                attempts += 1
            except Exception as ex:
                attempts = 0
                cycles += 1
                if cycles >= 3:
                    break
        return obj


