
from config import ASSOCIATIONS_OF_PR
from aiogram import F, Router
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import keyboards as kb
from parsers.HabrParser import HabrParser
from parsers.CyberForumParser import CyberForumParser
from datetime import *

router = Router()

class StatePos(StatesGroup):
    input_title = State()
    settings = State()

user_settings = {}

async def get_user_settings(user_id):
    return user_settings.get(user_id, {'hr': True, 'cf': False, 'sof': False, 'lastSec': 0})

async def set_user_settings(user_id, settings):
    user_settings[user_id] = settings

history_list = []

@router.message(CommandStart())
async def start_command(message: Message, state: FSMContext):
    user_id = message.from_user.id
    settings = await get_user_settings(user_id)
    last_sec = settings.get('lastSec')

    if (int(datetime.now().timestamp()) - 20) < last_sec:
        await message.answer("Запросы чаще 20 секунд.")
        return

    await message.answer("Привет, это парсер форумов программистов.")
    await message.answer("Введите запрос.", reply_markup=kb.keyboard_settings)
    await state.set_state(StatePos.input_title)
    

@router.message(Command(commands=["help"]))
async def help_command(message: Message):
    await message.answer("Список команд:\n/start - старт бота\n/help - помощь")
    
@router.message(F.text,StatePos.input_title)
async def handler_message(message: Message, state: FSMContext):
    user_id = message.from_user.id
    settings = await get_user_settings(user_id)
    last_sec = settings.get('lastSec')

    if (int(datetime.now().timestamp()) - 20) < last_sec:
        await message.answer("Запросы чаще 20 секунд.")
        return
    
    settings['lastSec'] = int(datetime.now().timestamp())
    await set_user_settings(user_id, settings)
        
    user_input = message.text.strip()

    if user_input.lower() == "настройки":
        await message.answer("Настройки бота", reply_markup=kb.settings)
        await state.set_state(StatePos.settings)
    else:
        await state.update_data(title=user_input)
        title = (await state.get_data()).get("title", "")

        parsers = [HabrParser, CyberForumParser]
        found_results = False

        for parser_class in parsers:
            parser = parser_class()
            results = parser.brow(title)

            if results:
                found_results = True
                await message.answer("Результаты парсинга:")
                for result in results:
                    entry = (
                        f"Название: {result.get('Название')}\n"
                        f"Аннотация: {result.get('Аннотация')}\n"
                        f"Ссылка: {result.get('Ссылка')}"
                    )
                    history_list.append(entry)
                    await message.answer(entry)
                    

        if not found_results:
            await message.answer("Ничего не найдено.")

@router.callback_query(F.data == 'history', StatePos.settings)
async def handler_history(callback: CallbackQuery, state: FSMContext):
    history = "\n\n".join(history_list) or "История пуста."
    await callback.message.edit_text(f"История:\n{history}", reply_markup=kb.back)

@router.callback_query(F.data == 'choose_site', StatePos.settings)
async def handler_choose_site(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    settings = await get_user_settings(user_id)
    await callback.message.edit_text("Выберите сайт", reply_markup=kb.site)

@router.callback_query(F.data == 'habr_button', StatePos.settings)
async def handler_habr(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    settings = await get_user_settings(user_id)
    settings['hr'] = not settings['hr']  
    await set_user_settings(user_id, settings)  

    button_label = "Выключено" if not settings['hr'] else "Включено"
    await callback.message.edit_text(
        f"Настройка Habr обновлена: {button_label}",
        reply_markup=kb.settings
    )

@router.callback_query(F.data == 'cyberforum_button', StatePos.settings)
async def handler_cyberforum(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    settings = await get_user_settings(user_id)
    settings['cf'] = not settings['cf']  
    await set_user_settings(user_id, settings)  

    button_label = "Выключено" if not settings['cf'] else "Включено"
    await callback.message.edit_text(
        f"Настройка CyberForum обновлена: {button_label}",
        reply_markup=kb.settings
    )

@router.callback_query(F.data == 'back_button', StatePos.settings)
async def handler_back_button(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    await callback.answer('')
    await callback.message.edit_text("Введите запрос.", reply_markup=None)
    await state.set_state(StatePos.input_title)

@router.message(F.photo)
async def handle_photo(message: Message):
    await message.answer("Отправка фото запрещена!")

@router.message(F.video)
async def handle_video(message: Message):
    await message.answer("Отправка видео запрещена!")

@router.message(F.document)
async def handle_document(message: Message):
    await message.answer("Отправка документов запрещена!")

@router.message(F.audio | F.video_note | F.voice)
async def handle_other_media(message: Message):
    await message.answer("Отправка этого типа медиа запрещена!")



